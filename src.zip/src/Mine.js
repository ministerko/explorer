import React, { useState, useEffect } from 'react'
import facts from './facts.json' // Importing the JSON file


function getRandomFact() {
  const category = 'wildlife' // Assuming you have only one category
  const randomFact =
    facts[category][Math.floor(Math.random() * facts[category].length)]
  return randomFact
}

function Main() {
  const [fact, setFact] = useState(null)

  useEffect(() => {
    const timer = setTimeout(() => {
      const randomFact = getRandomFact()
      setFact(randomFact)
    }, 6000) // 10 seconds delay

    return () => clearTimeout(timer) // Clear the timer on component unmount
  }, [fact]) // Re-run effect whenever fact changes

  return (
    <div>
     
      <div className="border-4 rounded-2xl p-7 inset-0 bg-black bg-opacity-50 text-white font-palanquin flex justify-center items-center">
        <div className="text-center">
          <h1 className="text-3xl text-wood font-montserrat mb-5 sm:text-xl">
            Did you know
          </h1>
          {fact && (
            <div>
              <p className="text-xl font-montserrat">{fact.description}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default Main
