import React from 'react'
import { serengeti, star ,ngoro,kilimanjaro,amazon} from './media'

const Body = () => {
  return (
    <section className="pt-20 bg-black px-10">
      <div className="text-center text-white text-4xl mb-10 font-montserrat">
      Explore <span className="text-wood">More</span>
      </div>
      <div className=" border-t-4 w-full border-wood"></div>
      <div className="grid grid-cols-4 grid-flow-row gap-4 mt-10 pb-10 sm:grid-cols-1  ko:grid-cols-2 ">
        <div className=" h-auto w-lg sm:h-x sm:w-full rounded-xl inset-0 bg-white bg-opacity-10 ">
          <img
            src={serengeti}
            alt="park1"
            className=" h-1/2 w-full mt-3 px-3 object-contain rounded-xl"
          />
          <div className="text-center mt-0">
            <a
              href="https://serengeti.com/"
              className="font-montserrat text-xl text-white"
            >
              serengeti
            </a>
            <div>
              <h1 className='text-wood font-montserrat'>" A timeless stage where nature's drama unfolds majestically"</h1>
            </div>
            <div className=' flex justify-center m-2 '>
             
              <img src={star} alt="park01" className="h-8 w-8 mb-5" />
              <h1 className='text-3xl text-white font- mb-5'>4.7</h1>
            </div>
          </div>
        </div>
        <div className=" h-auto w-lg sm:h-x sm:w-full rounded-xl inset-0 bg-white bg-opacity-10 ">
          <img
            src={ngoro}
            alt="park1"
            className=" h-1/2 w-full mt-3 px-3 object-contain rounded-xl"
          />
          <div className="text-center mt-0">
            <a
              href="https://serengeti.com/"
              className="font-montserrat text-xl text-white"
            >
              ngorongoro
            </a>
            <div>
              <h1 className='text-wood font-montserrat'>"Nature's amphitheater, where the circle of life echoes endlessly"</h1>
            </div>
            <div className=' flex justify-center m-2 '>
             
              <img src={star} alt="park01" className="h-8 w-8 mb-5" />
              <h1 className='text-3xl text-white font- mb-5'>4.7</h1>
            </div>
          </div>
        </div>
     

        <div className=" h-auto w-lg sm:h-x sm:w-full rounded-xl inset-0 bg-white bg-opacity-10 ">
          <img
            src={kilimanjaro}
            alt="park1"
            className=" h-1/2 w-full mt-3 px-3 object-contain rounded-xl"
          />
          <div className="text-center mt-0">
            <a
              href="https://serengeti.com/"
              className="font-montserrat text-xl text-white"
            >
              kilimanjaro
            </a>
            <div>
              <h1 className='text-wood font-montserrat'>"Majestic sentinel, touching the skies, inspiring awe and reverence"</h1>
            </div>
            <div className=' flex justify-center m-2 '>
             
              <img src={star} alt="park01" className="h-8 w-8 mb-5" />
              <h1 className='text-3xl text-white font- mb-5'>4.7</h1>
            </div>
          </div>
        </div>
     

        <div className=" h-auto w-lg sm:h-x sm:w-full rounded-xl inset-0 bg-white bg-opacity-10 ">
          <img
            src={amazon}
            alt="park1"
            className=" h-1/2 w-full mt-3 px-3 object-contain rounded-xl"
          />
          <div className="text-center mt-0">
            <a
              href="https://serengeti.com/"
              className="font-montserrat text-xl text-white"
            >
              amazon
            </a>
            <div>
              <h1 className='text-wood font-montserrat'>"A vibrant tapestry of life, pulsating with biodiversity"</h1>
            </div>
            <div className=' flex justify-center m-2 '>
             
              <img src={star} alt="park01" className="h-8 w-8 mb-5" />
              <h1 className='text-3xl text-white font- mb-5'>4.7</h1>
            </div>
          </div>
        </div>
     

     

      </div>
    </section>
  )
}

export default Body
