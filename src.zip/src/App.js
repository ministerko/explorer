import { fog, logow } from './media';
import Mine from '../src/Mine';

const App = () => {
  return (
    <div className="p-0 m-0 h-screen w-full ">
      <img src={logow} alt="logo" className=" absolute mt-0 h-60 w-60 " />
      <img className="h-full w-full object-cover" src={fog} />

      <div className="absolute top-0 left-0 h-full w-full flex justify-center items-center  ">
        <div className=" z-10 px-40 sm:px-10">
          <Mine />
        </div>
      </div>
    </div>
  );
};

export default App;
