import fog from './fog.png'
import serengeti from './serengeti.png'
import star from './star.png'
import ngoro from './ngoro.png'
import kilimanjaro from './kimanjaro.png'
import amazon from './amazon.png'
import logow from './logow.png'
export{
  fog,
  serengeti,
  star,
  ngoro,
  kilimanjaro,
  amazon,
  logow
}